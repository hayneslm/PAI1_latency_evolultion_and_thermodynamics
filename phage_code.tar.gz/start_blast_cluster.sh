#!/bin/bash

run_flag=$1

if [ $# -ne 1 ]; then
    run_flag=0
fi

ref="";
dir_name=""
script_dir=$dir_name"script/"
pbs_dir=$dir_name"pbs_files/"
in_dir=$dir_name"fasta/"
out_dir=$dir_name"blast_out/"
error_dir=$dir_name"error/"

cd $in_dir
fastq_files="$(ls *_R1*.fasta)"
for ff in $fastq_files;do
    echo $ff
    sname=${ff%*.fasta}
    out_filename=$out_dir$sname"_blast.txt"
    in_filename=$in_dir$ff
    pbs_filename=$pbs_dir$sname"_blast_R1.pbs"

    error_filename=$error_dir$sname"_error.log"
    output_filename=$error_dir$sname"_out.log"
    echo "#!/bin/bash" > $pbs_filename 
    echo "#SBATCH" >> $pbs_filename
    echo "#SBATCH --account=dginsburglab" >> $pbs_filename
    echo "#SBATCH --partition=dgcomp" >> $pbs_filename
    echo "#SBATCH --mail-user=siemieni@umich.edu" >> $pbs_filename
    echo "#SBATCH --job-name=$sname " >> $pbs_filename
    echo "#SBATCH --output=$output_filename" >> $pbs_filename
    echo "#SBATCH --error=$error_filename" >> $pbs_filename 
    echo "#SBATCH --nodes=1" >> $pbs_filename
    echo "#SBATCH --cpus-per-task=1 " >>$pbs_filename
    echo "#SBATCH --mem=5G " >>$pbs_filename
    echo "#SBATCH --time=120:00:00" >> $pbs_filename

    echo "blastn -db $ref -query $in_filename -out $out_filename -outfmt 0 -dust no " >> $pbs_filename
#    echo "blastn -db $ref -query $in_filename -out $out_filename -outfmt 0 -dust no -task blastn " >> $pbs_filename
#    echo "hs-blastn align -db $ref -query $in_filename -out $out_filename -outfmt 0 -dust no " >> $pbs_filename
    if [ $run_flag -eq 1 ]; then
	sbatch $pbs_filename 
    fi
done

fastq_files="$(ls *_R2*.fasta)"
for ff in $fastq_files;do
    echo $ff
    sname=${ff%*.fasta}
    out_filename=$out_dir$sname"_blast.txt"
    in_filename=$in_dir$ff
    pbs_filename=$pbs_dir$sname"_blast_R2.pbs"

    error_filename=$error_dir$sname"_error.log"
    output_filename=$error_dir$sname"_out.log"
    echo "#!/bin/bash" > $pbs_filename 
    echo "#SBATCH" >> $pbs_filename
    echo "#SBATCH --account=dginsburglab" >> $pbs_filename
    echo "#SBATCH --partition=dgcomp" >> $pbs_filename
    echo "#SBATCH --mail-user=siemieni@umich.edu" >> $pbs_filename
    echo "#SBATCH --job-name=$sname " >> $pbs_filename
    echo "#SBATCH --output=$output_filename" >> $pbs_filename
    echo "#SBATCH --error=$error_filename" >> $pbs_filename 
    echo "#SBATCH --nodes=1" >> $pbs_filename
    echo "#SBATCH --cpus-per-task=1 " >>$pbs_filename
    echo "#SBATCH --mem=5G " >>$pbs_filename
    echo "#SBATCH --time=120:00:00" >> $pbs_filename

    echo "blastn -db $ref -query $in_filename -out $out_filename -outfmt 0 -dust no " >> $pbs_filename
#    echo "blastn -db $ref -query $in_filename -out $out_filename -outfmt 0 -dust no -task blastn " >> $pbs_filename
    #	echo "hs-blastn align -db $ref -query $in_filename -out $out_filename -outfmt 0 -dust no " >> $pbs_filename
    if [ $run_flag -eq 1 ]; then
	sbatch $pbs_filename 
    fi
done
echo done
exit
