#!/usr/bin/perl -w              

use List::Util qw[min max];
$main_dirname = "";
require $main_dirname . "/script/process_proc.pl";

$title = $ARGV[0];
#print "title " . $title . "\n";
#$b=<STDIN>;
$in_dirname = $main_dirname . "blast_result/combine/";
$out_dirname = $main_dirname . "clean_result/";

$in_filename1 = $in_dirname . $title . "_R1_pai1_match.xls";
$in_filename2 = $in_dirname . $title . "_R2_pai1_match.xls";
#$in_filename1 = $in_dirname . $title . "_R1_pai1_match_100000.xls";
#$in_filename2 = $in_dirname . $title . "_R2_pai1_match_100000.xls";

$master_filename = $out_dirname . $title . "_master_count.xls";

$amp1_name = $out_dirname . $title . "_amp_1_valid_result.txt";
$amp1_gap_name = $out_dirname . $title . "_amp_1_gap_result.txt";
$amp1_seq_name = $out_dirname . $title . "_amp_1_seq_error_result.txt";
$amp2_name = $out_dirname . $title . "_amp_2_valid_result.txt";
$amp2_gap_name = $out_dirname . $title . "_amp_2_gap_result.txt";
$amp2_seq_name = $out_dirname . $title . "_amp_2_seq_error_result.txt";
$amp3_name = $out_dirname . $title . "_amp_3_valid_result.txt";
$amp3_gap_name = $out_dirname . $title . "_amp_3_gap_result.txt";
$amp3_seq_name = $out_dirname . $title . "_amp_3_seq_error_result.txt";
$amp4_name = $out_dirname . $title . "_amp_4_valid_result.txt";
$amp4_gap_name = $out_dirname . $title . "_amp_4_gap_result.txt";
$amp4_seq_name = $out_dirname . $title . "_amp_4_seq_error_result.txt";
$amp5_name = $out_dirname . $title . "_amp_5_valid_result.txt";
$amp5_gap_name = $out_dirname . $title . "_amp_5_gap_result.txt";
$amp5_seq_name = $out_dirname . $title . "_amp_5_seq_error_result.txt";
$amp6_name = $out_dirname . $title . "_amp_6_valid_result.txt";
$amp6_gap_name = $out_dirname . $title . "_amp_6_gap_result.txt";
$amp6_seq_name = $out_dirname . $title . "_amp_6_seq_error_result.txt";
$amp7_name = $out_dirname . $title . "_amp_7_valid_result.txt";
$amp7_gap_name = $out_dirname . $title . "_amp_7_gap_result.txt";
$amp7_seq_name = $out_dirname . $title . "_amp_7_seq_error_result.txt";
$amp8_name = $out_dirname . $title . "_amp_8_valid_result.txt";
$amp8_gap_name = $out_dirname . $title . "_amp_8_gap_result.txt";
$amp8_seq_name = $out_dirname . $title . "_amp_8_seq_error_result.txt";
$amp9_name = $out_dirname . $title . "_amp_9_valid_result.txt";
$amp9_gap_name = $out_dirname . $title . "_amp_9_gap_result.txt";
$amp9_seq_name = $out_dirname . $title . "_amp_9_seq_error_result.txt";
$amp10_name = $out_dirname . $title . "_amp_10_valid_result.txt";
$amp10_gap_name = $out_dirname . $title . "_amp_10_gap_result.txt";
$amp10_seq_name = $out_dirname . $title . "_amp_10_seq_error_result.txt";
$amp11_name = $out_dirname . $title . "_amp_11_valid_result.txt";
$amp11_gap_name = $out_dirname . $title . "_amp_11_gap_result.txt";
$amp11_seq_name = $out_dirname . $title . "_amp_11_seq_error_result.txt";
$amp12_name = $out_dirname . $title . "_amp_12_valid_result.txt";
$amp12_gap_name = $out_dirname . $title . "_amp_12_gap_result.txt";
$amp12_seq_name = $out_dirname . $title . "_amp_12_seq_error_result.txt";

$unknown_name = $out_dirname . $title . "_unknown_result.txt";
$display_name = $out_dirname . $title . "_display_result.txt";
$nomatch_name = $out_dirname . $title . "_no_match_result.txt";

if (-e $display_name) {`rm $display_name`}
#if (-e $data_name) {`rm $data_name`};
if (-e $amp1_name) {`rm $amp1_name`};
if (-e $amp1_gap_name) {`rm $amp1_gap_name`};
if (-e $amp1_seq_name) {`rm $amp1_seq_name`};
if (-e $amp2_name) {`rm $amp2_name`};
if (-e $amp2_gap_name) {`rm $amp2_gap_name`};
if (-e $amp2_seq_name) {`rm $amp2_seq_name`};
if (-e $amp3_name) {`rm $amp3_name`};
if (-e $amp3_gap_name) {`rm $amp3_gap_name`};
if (-e $amp3_seq_name) {`rm $amp3_seq_name`};
if (-e $amp4_name) {`rm $amp4_name`};
if (-e $amp4_gap_name) {`rm $amp4_gap_name`};
if (-e $amp4_seq_name) {`rm $amp4_seq_name`};
if (-e $amp5_name) {`rm $amp5_name`};
if (-e $amp5_gap_name) {`rm $amp5_gap_name`};
if (-e $amp5_seq_name) {`rm $amp5_seq_name`};
if (-e $amp6_name) {`rm $amp6_name`};
if (-e $amp6_gap_name) {`rm $amp6_gap_name`};
if (-e $amp6_seq_name) {`rm $amp6_seq_name`};
if (-e $amp7_name) {`rm $amp7_name`};
if (-e $amp7_gap_name) {`rm $amp7_gap_name`};
if (-e $amp7_seq_name) {`rm $amp7_seq_name`};
if (-e $amp8_name) {`rm $amp8_name`};
if (-e $amp8_gap_name) {`rm $amp8_gap_name`};
if (-e $amp8_seq_name) {`rm $amp8_seq_name`};
if (-e $amp9_name) {`rm $amp9_name`};
if (-e $amp9_gap_name) {`rm $amp9_gap_name`};
if (-e $amp9_seq_name) {`rm $amp9_seq_name`};
if (-e $amp10_name) {`rm $amp10_name`};
if (-e $amp10_gap_name) {`rm $amp10_gap_name`};
if (-e $amp10_seq_name) {`rm $amp10_seq_name`};
if (-e $amp11_name) {`rm $amp11_name`};
if (-e $amp11_gap_name) {`rm $amp11_gap_name`};
if (-e $amp11_seq_name) {`rm $amp11_seq_name`};
if (-e $amp12_name) {`rm $amp12_name`};
if (-e $amp12_gap_name) {`rm $amp12_gap_name`};
if (-e $amp12_seq_name) {`rm $amp12_seq_name`};
if (-e $unknown_name) {`rm $unknown_name`};
if (-e $nomatch_name) {`rm $nomatch_name`};

open (A1_OUT,">$amp1_name") or die "Cannot open $! " . $amp1_name;
print A1_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A1_GAP_OUT,">$amp1_gap_name") or die "Cannot open $! " . $amp1_gap_name;
print A1_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A1_SEQ_OUT,">$amp1_seq_name") or die "Cannot open $! " . $amp1_seq_name;
print A1_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A2_OUT,">$amp2_name") or die "Cannot open $! " . $amp2_name;
print A2_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A2_GAP_OUT,">$amp2_gap_name") or die "Cannot open $! " . $amp2_gap_name;
print A2_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A2_SEQ_OUT,">$amp2_seq_name") or die "Cannot open $! " . $amp2_seq_name;
print A2_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A3_OUT,">$amp3_name") or die "Cannot open $! " . $amp3_name;
print A3_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A3_GAP_OUT,">$amp3_gap_name") or die "Cannot open $! " . $amp3_gap_name;
print A3_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A3_SEQ_OUT,">$amp3_seq_name") or die "Cannot open $! " . $amp3_seq_name;
print A3_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A4_OUT,">$amp4_name") or die "Cannot open $! " . $amp4_name;
print A4_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A4_GAP_OUT,">$amp4_gap_name") or die "Cannot open $! " . $amp4_gap_name;
print A4_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A4_SEQ_OUT,">$amp4_seq_name") or die "Cannot open $! " . $amp4_seq_name;
print A4_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A5_OUT,">$amp5_name") or die "Cannot open $! " . $amp5_name;
print A5_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A5_GAP_OUT,">$amp5_gap_name") or die "Cannot open $! " . $amp5_gap_name;
print A5_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A5_SEQ_OUT,">$amp5_seq_name") or die "Cannot open $! " . $amp5_seq_name;
print A5_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A6_OUT,">$amp6_name") or die "Cannot open $! " . $amp6_name;
print A6_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A6_GAP_OUT,">$amp6_gap_name") or die "Cannot open $! " . $amp6_gap_name;
print A6_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A6_SEQ_OUT,">$amp6_seq_name") or die "Cannot open $! " . $amp6_seq_name;
print A6_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A7_OUT,">$amp7_name") or die "Cannot open $! " . $amp7_name;
print A7_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A7_GAP_OUT,">$amp7_gap_name") or die "Cannot open $! " . $amp7_gap_name;
print A7_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A7_SEQ_OUT,">$amp7_seq_name") or die "Cannot open $! " . $amp7_seq_name;
print A7_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A8_OUT,">$amp8_name") or die "Cannot open $! " . $amp8_name;
print A8_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A8_GAP_OUT,">$amp8_gap_name") or die "Cannot open $! " . $amp8_gap_name;
print A8_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A8_SEQ_OUT,">$amp8_seq_name") or die "Cannot open $! " . $amp8_seq_name;
print A8_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A9_OUT,">$amp9_name") or die "Cannot open $! " . $amp9_name;
print A9_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A9_GAP_OUT,">$amp9_gap_name") or die "Cannot open $! " . $amp9_gap_name;
print A9_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A9_SEQ_OUT,">$amp9_seq_name") or die "Cannot open $! " . $amp9_seq_name;
print A9_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A10_OUT,">$amp10_name") or die "Cannot open $! " . $amp10_name;
print A10_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A10_GAP_OUT,">$amp10_gap_name") or die "Cannot open $! " . $amp10_gap_name;
print A10_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A10_SEQ_OUT,">$amp10_seq_name") or die "Cannot open $! " . $amp10_seq_name;
print A10_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A11_OUT,">$amp11_name") or die "Cannot open $! " . $amp11_name;
print A11_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A11_GAP_OUT,">$amp11_gap_name") or die "Cannot open $! " . $amp11_gap_name;
print A11_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A11_SEQ_OUT,">$amp11_seq_name") or die "Cannot open $! " . $amp11_seq_name;
print A11_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (A12_OUT,">$amp12_name") or die "Cannot open $! " . $amp12_name;
print A12_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A12_GAP_OUT,">$amp12_gap_name") or die "Cannot open $! " . $amp12_gap_name;
print A12_GAP_OUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";
open (A12_SEQ_OUT,">$amp12_seq_name") or die "Cannot open $! " . $amp12_seq_name;
print A12_SEQ_OUT join("\t","#Mismatch","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","Flag") . "\n";

open (UNKNOWN,">$unknown_name") or die "Cannot open $! " . $unknown_name;
print UNKNOWN join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","R1 %","R2 %","R1 ref start","R1 ref End","R2 ref Start","R2 ref End","R1 Gaps","R2 Gaps","Flag") . "\n";
open (DISPLAY,">$display_name") or die "Cannot open $! " . $display_name;
open (NOMATCH,">$nomatch_name") or die "Cannot open $! " . $nomatch_name;
print NOMATCH "Seq Id\n";

##human pai1 numbers
$offset = 5;
$a1_start = 1;
$a1_end = 150 + $offset;
$a2_start = 100 - $offset;
$a2_end = 248 + $offset;
$a3_start = 175 - $offset;
$a3_end = 324 + $offset;
$a4_start = 262 - $offset;
$a4_end = 411 + $offset;
$a5_start = 352 - $offset;
$a5_end = 501 + $offset;
$a6_start = 441 - $offset;
$a6_end = 590 + $offset;
$a7_start = 541 - $offset;
$a7_end = 690 + $offset;
$a8_start = 640 - $offset;
$a8_end = 789 + $offset;
$a9_start = 742 - $offset;
$a9_end = 891 + $offset;
$a10_start = 843 - $offset;
$a10_end = 992 + $offset;
$a11_start = 940 - $offset;
$a11_end = 1089 + $offset;
$a12_start = 1051 - $offset;
$a12_end = 1200 + $offset;

$a1_cnt = 0;
$a1_gap_cnt = 0;
$a1_seq_cnt = 0;
$a1_per_cnt = 0;
$a2_cnt = 0;
$a2_gap_cnt = 0;
$a2_seq_cnt = 0;
$a2_per_cnt = 0;
$a3_cnt = 0;
$a3_gap_cnt = 0;
$a3_seq_cnt = 0;
$a3_per_cnt = 0;
$a4_cnt = 0;
$a4_gap_cnt = 0;
$a4_seq_cnt = 0;
$a4_per_cnt = 0;
$a5_cnt = 0;
$a5_gap_cnt = 0;
$a5_seq_cnt = 0;
$a5_per_cnt = 0;
$a6_cnt = 0;
$a6_gap_cnt = 0;
$a6_seq_cnt = 0;
$a6_per_cnt = 0;
$a7_cnt = 0;
$a7_gap_cnt = 0;
$a7_seq_cnt = 0;
$a7_per_cnt = 0;
$a8_cnt = 0;
$a8_gap_cnt = 0;
$a8_seq_cnt = 0;
$a8_per_cnt = 0;
$a9_cnt = 0;
$a9_gap_cnt = 0;
$a9_seq_cnt = 0;
$a9_per_cnt = 0;
$a10_cnt = 0;
$a10_gap_cnt = 0;
$a10_seq_cnt = 0;
$a10_per_cnt = 0;
$a11_cnt = 0;
$a11_gap_cnt = 0;
$a11_seq_cnt = 0;
$a11_per_cnt = 0;
$a12_cnt = 0;
$a12_gap_cnt = 0;
$a12_seq_cnt = 0;
$a12_per_cnt = 0;
$a13_cnt = 0;
$unk_cnt = 0;
$a1_total = 0;
$a2_total = 0;
$a3_total = 0;
$a4_total = 0;
$a5_total = 0;
$a6_total = 0;
$a7_total = 0;
$a8_total = 0;
$a9_total = 0;
$a10_total = 0;
$a11_total = 0;
$a12_total = 0;

$start_time = time();
$st_time = $start_time;
print "Start Input R2 " . "\n";
$r2_cnt = 0;
undef(%r2_data);
open(INFILE2,"$in_filename2") || die "cannot read " . $in_filename2;
#readline(*INFILE2);
while(<INFILE2>) {
    $_ =~ s/\r|\n//g;
    @line = split("\t",$_);
    $line[0] =~ tr/@//d;
    @tline = split(" ",$line[0]);
    $r2_cnt ++;
    if ($r2_cnt % 1000000 == 0) {
	$t_time = time();
#	print "Time " . ($t_time - $st_time) . "\n";
#	print "Seq cnt " . $r2_cnt . "\n";
	print DISPLAY "Time " . ($t_time - $st_time) . "\n";
	print DISPLAY "Seq cnt " . $r2_cnt . "\n";
	$st_time = $t_time;
    }
    if ($line[9] == -1) {
	$line[1] = reverse_compliment($line[1]);
    }
    $r2_data{$tline[0]} = [$line[1],$line[3],$line[4],$line[5],$line[6],$line[9],$line[10]]; 
}## end infile input
close(INFILE2);
$st_time = time();
$scan_time = $st_time - $start_time;
#print "Load time " . ($st_time - $start_time) . "\n";
#print "Seq cnt " . $r2_cnt . "\n";
print DISPLAY "Load time " . ($st_time - $start_time) . "\n";
print DISPLAY "Seq cnt " . $r2_cnt . "\n";
#$b=<STDIN>;

$r1_cnt = 0;
$mis_match_cnt = 0;
$valid_cnt = 0;
print "Start Scan R1 " . "\n";
open(INFILE1,"$in_filename1") || die "cannot read " . $in_filename1;
#readline(*INFILE1);
while(<INFILE1>) {
    $_ =~ s/\r|\n//g;
    @line = split("\t",$_);
    $line[0] =~ tr/@//d;
    @tline = split(" ",$line[0]);
#    for ($tt=0;$tt<=$#line;$tt++) {
#	print "tt " . $tt . " - " .$line[$tt] . "\n";
#    }
#    print "tline " . $tline[0] . "\n";
#    $b=<STDIN>;    

    $r1_cnt ++;
    if ($r1_cnt % 1000000 == 0) {
	$t_time = time();
	print DISPLAY "time " . ($t_time - $st_time) . "\n";
	print DISPLAY "R1 Cnt " . $r1_cnt . " mis_match_cnt " . $mis_match_cnt . " valid_cnt " . $valid_cnt. "\n";
	print DISPLAY "A1: " . $a1_cnt . " a2: " . $a2_cnt . " a3: " . $a3_cnt . " a4: " . $a4_cnt . " a5: " . $a5_cnt. " a6: " . $a6_cnt. " a7: " . $a7_cnt . " a8: " . $a8_cnt . " a9: " . $a9_cnt . " a10: " . $a10_cnt . " a11: " . $a11_cnt . " a12: " . $a12_cnt . " a13: " . $a13_cnt . " unk_cnt " . $unk_cnt. "\n";
	print DISPLAY "A1_seq " . $a1_seq_cnt . " A2_seq " . $a2_seq_cnt . " A3_seq " . $a3_seq_cnt . " A4_seq " . $a4_seq_cnt . " A5_seq " . $a5_seq_cnt . " A6_seq " . $a6_seq_cnt . " A7_seq " . $a7_seq_cnt . " A8_seq " . $a8_seq_cnt . " A9_seq " . $a9_seq_cnt . " A10_seq " . $a10_seq_cnt . " A11_seq " . $a11_seq_cnt . " A12_seq " . $a12_seq_cnt. "\n";
	print DISPLAY "A1_gap " . $a1_gap_cnt . " A2_gap " . $a2_gap_cnt . " A3_gap " . $a3_gap_cnt . " A4_gap " . $a4_gap_cnt . " A5_gap " . $a5_gap_cnt . " A6_gap " . $a6_gap_cnt . " A7_gap " . $a7_gap_cnt . " A8_gap " . $a8_gap_cnt . " A9_gap " . $a9_gap_cnt . " A10_gap " . $a10_gap_cnt . " A11_gap " . $a11_gap_cnt . " A12_gap " . $a12_gap_cnt. "\n";
	print DISPLAY "A1_per " . $a1_per_cnt . " A2_per " . $a2_per_cnt . " A3_per " . $a3_per_cnt . " A4_per " . $a4_per_cnt . " A5_per " . $a5_per_cnt . " A6_per " . $a6_per_cnt . " A7_per " . $a7_per_cnt . " A8_seq " . $a8_per_cnt . " A9_seq " . $a9_per_cnt. " A10_seq " . $a10_per_cnt. " A11_seq " . $a11_per_cnt. " A12_seq " . $a12_per_cnt . "\n";
	print DISPLAY "a1 total " . $a1_total . " a2 total " . $a2_total ." a3 total ". $a3_total ." a4 total ". $a4_total ." a5 total ". $a5_total ." a6 total ". $a6_total ." a7 total " . $a7_total . " a8 total " . $a8_total . " a9 total " . $a9_total . " a10 total " . $a10_total . " a11 total " . $a11_total . " a12 total " . $a12_total. "\n";
    }

##may have to use the grep command here if memory issues

    if (exists($r2_data{$tline[0]})) {
	if ($line[9] == -1) {
	    $line[1] = reverse_compliment($line[1]);
	}
	$valid_cnt ++;
	if ($line[3] <= $r2_data{$tline[0]}[1]) {
	    $st_pos = $line[3];
	    $r1_seq = $line[1];
	    if ($r2_data{$tline[0]}[1] >= $st_pos && $r2_data{$tline[0]}[1] <= $line[4]) {
		if ($line[3] == $r2_data{$tline[0]}[1]) {
		    if ($line[4] < $r2_data{$tline[0]}[2]) {
			$end_pos = $r2_data{$tline[0]}[2];
		    } else {
			$end_pos = $line[4];
		    }
		} else {
		    $end_pos = $r2_data{$tline[0]}[2];
		}
		$outline = join("\t",$tline[0],$r1_seq,$r2_data{$tline[0]}[0],$st_pos,$end_pos,$line[6],$r2_data{$tline[0]}[4],$line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[10],$r2_data{$tline[0]}[6],"R1") . "\n";
	    } else {
		print UNKNOWN join("\t",$tline[0],$line[1],$r2_data{$tline[0]}[0],$line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[6],$r2_data{$tline[0]}[4],$line[10],$r2_data{$tline[0]}[6],"R1U") . "\n";
		$unk_cnt ++;
		next;
	    }
	} else { ##line[3] > r2_data[1]
	    $st_pos = $r2_data{$tline[0]}[1];
	    $r1_seq = $r2_data{$tline[0]}[0];
	    if ($line[3] >= $st_pos && $line[3] <= $r2_data{$tline[0]}[2]) {
		$outline = join("\t",$tline[0],$r1_seq,$line[1],$st_pos,$line[4],$r2_data{$tline[0]}[4],$line[6],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[3],$line[4],$r2_data{$tline[0]}[6],$line[10],"R2") . "\n";
		$end_pos = $line[4];
	    } else {
		print UNKNOWN join("\t",$tline[0],$r2_data{$tline[0]}[0],$line[1],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[3],$line[4],$r2_data{$tline[0]}[4],$line[6],$r2_data{$tline[0]}[6],$line[10],"R2U") . "\n";
		$unk_cnt ++;
		next;
	    }
	}## end else line[3] . r2_data
#	print "st_pos " . $st_pos . " end_pos " . $end_pos . "\n"; 
	#	$b=<STDIN>;
	## now I have to find amplicon
	#####################################################
	if ($st_pos >= $a1_start && $end_pos <= $a1_end) {
	    $a1_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A1_GAP_OUT $outline;
		$a1_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A1_OUT $outline;
		$a1_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A1_SEQ_OUT "\t" .$cnt[0] . "\t".$outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a1_seq_cnt ++;
		} else {
		    print A1_OUT $outline;
		    $a1_cnt ++;
		}
	    } else {
		print A1_OUT $outline;
		$a1_cnt ++;
	    }
		
	} elsif ($st_pos >= $a2_start && $end_pos <= $a2_end) {
	    $a2_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A2_GAP_OUT $outline;
		$a2_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A2_OUT $outline;
		$a2_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A2_SEQ_OUT "\t" .$cnt[2] ."\t".$outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a2_seq_cnt ++;
		} else {
		    print A2_OUT $outline;
		    $a2_cnt ++;
		}
	    } else {
		print A2_OUT $outline;
		$a2_cnt ++;
	    }
	} elsif ($st_pos >= $a3_start && $end_pos <= $a3_end) {
	    $a3_total ++;
#	    print "out " . $outline . "\n";
#	    $b=<STDIN>;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A3_GAP_OUT $outline;
		$a3_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A3_OUT $outline;
		$a3_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A3_SEQ_OUT "\t" .$cnt[0] ."\t". $outline . "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a3_seq_cnt ++;
		} else {
		    print A3_OUT $outline;
		    $a3_cnt ++;
		}
	    } else {
		print A3_OUT $outline;
		$a3_cnt ++;
	    }
	} elsif ($st_pos >= $a4_start && $end_pos <= $a4_end) {
	    $a4_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A4_GAP_OUT $outline;
		$a4_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A4_OUT $outline;
		$a4_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A4_SEQ_OUT "\t" .$cnt[0] . "\t".$outline . "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a4_seq_cnt ++;
		} else {
		    print A4_OUT $outline;
		    $a4_cnt ++;
		}
	    } else {
		print A4_OUT $outline;
		$a4_cnt ++;
	    }
	} elsif ($st_pos >= $a5_start && $end_pos <= $a5_end) {
	    $a5_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A5_GAP_OUT $outline;
		$a5_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A5_OUT $outline;
		$a5_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A5_SEQ_OUT "\t" .$cnt[0] . "\t".$outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a5_seq_cnt ++;
		} else {
		    print A5_OUT $outline;
		    $a5_cnt ++;
		}
	    } else {
		print A5_OUT $outline;
		$a5_cnt ++;
	    }
	} elsif ($st_pos >= $a6_start && $end_pos <= $a6_end) {
	    $a6_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A6_GAP_OUT $outline;
		$a6_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A6_OUT $outline;
		$a6_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A6_SEQ_OUT "\t" .$cnt[0] ."\t".$outline . "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a6_seq_cnt ++;
		} else {
		    print A6_OUT $outline;
		    $a6_cnt ++;
		}
	    } else {
		print A6_OUT $outline;
		$a6_cnt ++;
	    }
	} elsif ($st_pos >= $a7_start && $end_pos <= $a7_end) {
	    $a7_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A7_GAP_OUT $outline;
		$a7_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A7_OUT $outline;
		$a7_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A7_SEQ_OUT "\t" .$cnt[0] . "\t". $outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a7_seq_cnt ++;
		} else {
		    print A7_OUT $outline;
		    $a7_cnt ++;
		}
	    } else {
		print A7_OUT $outline;
		$a7_cnt ++;
	    }
	} elsif ($st_pos >= $a8_start && $end_pos <= $a8_end) {
	    $a8_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A8_GAP_OUT $outline;
		$a8_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A8_OUT $outline;
		$a8_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A8_SEQ_OUT "\t" .$cnt[0] . "\t". $outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a8_seq_cnt ++;
		} else {
		    print A8_OUT $outline;
		    $a8_cnt ++;
		}
	    } else {
		print A8_OUT $outline;
		$a8_cnt ++;
	    }
	} elsif ($st_pos >= $a9_start && $end_pos <= $a9_end) {
	    $a9_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A9_GAP_OUT $outline;
		$a9_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A9_OUT $outline;
		$a9_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A9_SEQ_OUT "\t" .$cnt[0] . "\t". $outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a9_seq_cnt ++;
		} else {
		    print A9_OUT $outline;
		    $a9_cnt ++;
		}
	    } else {
		print A9_OUT $outline;
		$a9_cnt ++;
	    }
	} elsif ($st_pos >= $a10_start && $end_pos <= $a10_end) {
	    $a10_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A10_GAP_OUT $outline;
		$a10_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A10_OUT $outline;
		$a10_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A10_SEQ_OUT "\t" .$cnt[0] . "\t". $outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a10_seq_cnt ++;
		} else {
		    print A10_OUT $outline;
		    $a10_cnt ++;
		}
	    } else {
		print A10_OUT $outline;
		$a10_cnt ++;
	    }
	} elsif ($st_pos >= $a11_start && $end_pos <= $a11_end) {
	    $a11_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A11_GAP_OUT $outline;
		$a11_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A11_OUT $outline;
		$a11_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A11_SEQ_OUT "\t" .$cnt[0] . "\t". $outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a11_seq_cnt ++;
		} else {
		    print A11_OUT $outline;
		    $a11_cnt ++;
		}
	    } else {
		print A11_OUT $outline;
		$a11_cnt ++;
	    }
	} elsif ($st_pos >= $a12_start && $end_pos <= $a12_end) {
	    $a12_total ++;
	    if ($line[10] > 0 || $r2_data{$tline[0]}[6] > 0) {
		print A12_GAP_OUT $outline;
		$a12_gap_cnt ++;
	    } elsif ($line[6] == 100 && $r2_data{$tline[0]}[4] == 100) {
		print A12_OUT $outline;
		$a12_per_cnt ++;
	    } elsif (($line[6] < 100 && $r2_data{$tline[0]}[4] == 100) || ($line[6] == 100 && $r2_data{$tline[0]}[4] < 100)) {
		@cnt = compare_reads($line[3],$line[4],$r2_data{$tline[0]}[1],$r2_data{$tline[0]}[2],$line[1],$r2_data{$tline[0]}[0]);
		if ($cnt[0]) {
		    chop($outline);
		    print A12_SEQ_OUT "\t" .$cnt[0] . "\t". $outline. "\t" . $cnt[1] . "\t" . $cnt[2] . "\n";
		    $a12_seq_cnt ++;
		} else {
		    print A12_OUT $outline;
		    $a12_cnt ++;
		}
	    } else {
		print A12_OUT $outline;
		$a12_cnt ++;
	    }
	} else {
	    print UNKNOWN $outline;
	    $a13_cnt ++;
	}
    } else { ##if exists R2
	print NOMATCH $line[0] . "\n";
	$mis_match_cnt ++;
#	$b=<STDIN>;
    }
}##iINFILE2    
close(INFILE1);
#close(DATA);
close(A1_OUT);
close(A1_SEQ_OUT);
close(A1_GAP_OUT);
close(A2_OUT);
close(A2_SEQ_OUT);
close(A2_GAP_OUT);
close(A3_OUT);
close(A3_SEQ_OUT);
close(A3_GAP_OUT);
close(A4_OUT);
close(A4_SEQ_OUT);
close(A4_GAP_OUT);
close(A5_OUT);
close(A5_SEQ_OUT);
close(A5_GAP_OUT);
close(A6_OUT);
close(A6_SEQ_OUT);
close(A6_GAP_OUT);
close(A7_OUT);
close(A7_SEQ_OUT);
close(A7_GAP_OUT);
close(A8_OUT);
close(A8_SEQ_OUT);
close(A8_GAP_OUT);
close(A9_OUT);
close(A9_SEQ_OUT);
close(A9_GAP_OUT);
close(A10_OUT);
close(A10_SEQ_OUT);
close(A10_GAP_OUT);
close(A11_OUT);
close(A11_SEQ_OUT);
close(A11_GAP_OUT);
close(A12_OUT);
close(A12_SEQ_OUT);
close(A12_GAP_OUT);

close(UNKNOWN);
close(NOMATCH);

$t_time = time();
$search_time = $t_time - $st_time;
$total_time = $t_time - $start_time;
#print "\ntotal time " . $total_time . "\n";
#print "Scan Time " . $scan_time . " search time " . $search_time. "\n";
#print "R1 Cnt " . $r1_cnt . " R2 Cnt " . $r2_cnt . " mis match cnt " . $mis_match_cnt . " valid_cnt " . $valid_cnt . "\n";
#print "A1: " . $a1_cnt . " a2: " . $a2_cnt . " a3: " . $a3_cnt . " a4: " . $a4_cnt . " a5: " . $a5_cnt. " a6: " . $a6_cnt. " a7: " . $a7_cnt . " a8: " . $a8_cnt. " a9: " . $a9_cnt. " a10: " . $a10_cnt. " a11: " . $a11_cnt. " a12: " . $a12_cnt. " a13: " . $a13_cnt. "\n";
#print "A1_seq " . $a1_seq_cnt . " A2_seq " . $a2_seq_cnt . " A3_seq " . $a3_seq_cnt . " A4_seq " . $a4_seq_cnt . " A5_seq " . $a5_seq_cnt . " A6_seq " . $a6_seq_cnt . " A7_seq " . $a7_seq_cnt . " A8_seq " . $a8_seq_cnt . " A9_seq " . $a9_seq_cnt . " A10_seq " . $a10_seq_cnt . " A11_seq " . $a11_seq_cnt . " A12_seq " . $a12_seq_cnt. "\n";
#print "A1_gap " . $a1_gap_cnt . " A2_seq " . $a2_gap_cnt . " A3_seq " . $a3_gap_cnt . " A4_seq " . $a4_gap_cnt . " A5_seq " . $a5_gap_cnt . " A6_seq " . $a6_gap_cnt . " A7_seq " . $a7_gap_cnt . " A8_seq " . $a8_gap_cnt . " A9_seq " . $a9_gap_cnt . " A10_seq " . $a10_gap_cnt . " A11_seq " . $a11_gap_cnt . " A12_seq " . $a12_gap_cnt. "\n";
#print "A1_per " . $a1_per_cnt . " A2_seq " . $a2_per_cnt . " A3_seq " . $a3_per_cnt . " A4_seq " . $a4_per_cnt . " A5_seq " . $a5_per_cnt . " A6_seq " . $a6_per_cnt . " A7_seq " . $a7_per_cnt . " A8_seq " . $a8_per_cnt . " A9_seq " . $a9_per_cnt. " A10_seq " . $a10_per_cnt. " A11_seq " . $a11_per_cnt. " A12_seq " . $a12_per_cnt. "\n"; 
#print "a1 total " . $a1_total . " a2 total ". $a2_total ." a3 total ". $a3_total ." a4 total ". $a4_total ." a5 total ". $a5_total ." a6 total ". $a6_total ." a7 total ". $a7_total . " a8 total ". $a8_total . " a9 total ". $a9_total. " a10 total ". $a10_total. " a11 total ". $a11_total. " a12 total ". $a12_total. "\n";

print DISPLAY "\ntotal time " . ($t_time - $start_time) . "\n";
print DISPLAY "Scan Time " . $scan_time . " search time " . $search_time. "\n";
print DISPLAY "R1 Cnt " . $r1_cnt . " R2 Cnt " . $r2_cnt . " mis match cnt " . $mis_match_cnt . " valid_cnt " . $valid_cnt . "\n";
print DISPLAY "A1: " . $a1_cnt . " a2: " . $a2_cnt . " a3: " . $a3_cnt . " a4: " . $a4_cnt . " a5: " . $a5_cnt. " a6: " . $a6_cnt. " a7: " . $a7_cnt . " a8: " . $a8_cnt . " a9: " . $a9_cnt. " a10: " . $a10_cnt. " a11: " . $a11_cnt. " a12: " . $a12_cnt. " a13: " . $a13_cnt. "\n";
print DISPLAY "A1_seq " . $a1_seq_cnt . " A2_seq " . $a2_seq_cnt . " A3_seq " . $a3_seq_cnt . " A4_seq " . $a4_seq_cnt . " A5_seq " . $a5_seq_cnt . " A6_seq " . $a6_seq_cnt . " A7_seq " . $a7_seq_cnt . " A8_seq " . $a8_seq_cnt . " A9_seq " . $a9_seq_cnt . " A10_seq " . $a10_seq_cnt . " A11_seq " . $a11_seq_cnt . " A12_seq " . $a12_seq_cnt . "\n";
print DISPLAY "A1_gap " . $a1_gap_cnt . " A2_gap " . $a2_gap_cnt . " A3_gap " . $a3_gap_cnt . " A4_gap " . $a4_gap_cnt . " A5_gap " . $a5_gap_cnt . " A6_gap " . $a6_gap_cnt . " A7_gap " . " A8_gap " . $a8_gap_cnt . " A9_gap " . $a9_gap_cnt . " A10_seq " . $a10_gap_cnt . " A11_seq " . $a11_gap_cnt . " A12_seq " . $a12_gap_cnt . "\n";
print DISPLAY "A1_per " . $a1_per_cnt . " A2_per " . $a2_per_cnt . " A3_per " . $a3_per_cnt . " A4_per " . $a4_per_cnt . " A5_per " . $a5_per_cnt . " A6_per " . $a6_per_cnt . " A7_per " . $a7_per_cnt . " A8_seq " . $a8_per_cnt . " A9_seq " . $a9_per_cnt. " A10_seq " . $a10_per_cnt. " A11_seq " . $a11_per_cnt. " A12_seq " . $a12_per_cnt . "\n";
print DISPLAY "a1 total " . $a1_total . " a2 total ". $a2_total ." a3 total ". $a3_total ." a4 total ". $a4_total ." a5 total ". $a5_total ." a6 total ". $a6_total ." a7 total ". $a7_total . " a8 total ". $a8_total . " a9 total ". $a9_total. " a10 total ". $a10_total. " a11 total ". $a11_total. " a12 total ". $a12_total. "\n";

open(M_LIST,">>$master_filename") || die "cannot open " . $master_filename;
print M_LIST "title,r1_cnt,r2_cnt,mis_match_cnt,a1_cnt,a1_seq_cnt,a1_gap_cnt,a1_per_cnt,a1_total,a2_cnt,a2_seq_cnt,a2_gap_cnt,a2_per_cnt,a2_total,a3_cnt,a3_seq_cnt,a3_gap_cnt,a3_per_cnt,a3_total,a4_cnt,a4_seq_cnt,a4_gap_cnt,a4_per_cnt,a4_total,a5_cnt,a5_seq_cnt,a5_gap_cnt,a5_per_cnt,a5_total,a6_cnt,a6_seq_cnt,a6_gap_cnt,a6_per_cnt,a6_total,a7_cnt,a7_seq_cnt,a7_gap_cnt,a7_per_cnt,a7_total,a8_cnt,a8_seq_cnt,a8_gap_cnt,a8_per_cnt,a8_total,a9_cnt,a9_seq_cnt,a9_gap_cnt,a9_per_cnt,a9_total,a10_cnt,a10_seq_cnt,a10_gap_cnt,a10_per_cnt,a10_total,a11_cnt,a11_seq_cnt,a11_gap_cnt,a11_per_cnt,a11_total,a12_cnt,a12_seq_cnt,a12_gap_cnt,a12_per_cnt,a12_total,a13_cnt,valid_cnt,scan_time,search_time,total_time" . "\n";
print M_LIST join(",",$title,,$r1_cnt,$r2_cnt,$mis_match_cnt,$a1_cnt,$a1_seq_cnt,$a1_gap_cnt,$a1_per_cnt,$a1_total,$a2_cnt,$a2_seq_cnt,$a2_gap_cnt,$a2_per_cnt,$a2_total,$a3_cnt,$a3_seq_cnt,$a3_gap_cnt,$a3_per_cnt,$a3_total,$a4_cnt,$a4_seq_cnt,$a4_gap_cnt,$a4_per_cnt,$a4_total,$a5_cnt,$a5_seq_cnt,$a5_gap_cnt,$a5_per_cnt,$a5_total,$a6_cnt,$a6_seq_cnt,$a6_gap_cnt,$a6_per_cnt,$a6_total,$a7_cnt,$a7_seq_cnt,$a7_gap_cnt,$a7_per_cnt,$a7_total,$a8_cnt,$a8_seq_cnt,$a8_gap_cnt,$a8_per_cnt,$a8_total,$a9_cnt,$a9_seq_cnt,$a9_gap_cnt,$a9_per_cnt,$a9_total,$a10_cnt,$a10_seq_cnt,$a10_gap_cnt,$a10_per_cnt,$a10_total,$a11_cnt,$a11_seq_cnt,$a11_gap_cnt,$a11_per_cnt,$a11_total,$a12_cnt,$a12_seq_cnt,$a12_gap_cnt,$a12_per_cnt,$a12_total,$a13_cnt,$valid_cnt,$scan_time,$search_time,$total_time) . "\n";
close(M_LIST);

$end_time = time();
print DISPLAY "\nTotal Time " . ($end_time - $start_time) . "\n";
close(DISPLAY);

exit 0;
