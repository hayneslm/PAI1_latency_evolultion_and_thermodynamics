#!/usr/bin/perl -w              
use IO::Uncompress::Gunzip;

$tmp_title = $ARGV[0];

@a_title = split("_",$tmp_title);
#for ($tt=0;$tt<=$#a_title;$tt++) {
#    print "tt " . $tt . " value " . $a_title[$tt] ."\n";
#}
#$b=<STDIN>;
#$lane = int(substr($a_title[2],4));
$id = $a_title[0];
#@tmp = split("[.]",$tmp_title);
#$id = $tmp[0];
#$strand = $tmp[0];

$main_dirname = "";
$in_dirname = $main_dirname . "fastq/";
$out_dirname = $main_dirname . "clean_convert/";
$tmp_dirname = $main_dirname . "fasta/";

$total_sample_cnt = 0;
$total_blseq_cnt = 0;
$total_reject_cnt = 0;
$sample_cnt = 0;
$reject_cnt = 0;
$blseq_cnt = 0;

$N_percent_cutoff = 0.1;
$nuc_percent_cutoff = 0.8;

$in_filename = $in_dirname . $tmp_title;
#$title = $id ;
$title = substr($id,0,7) . "_" . substr($a_title[1],0,6) . "_" . $a_title[3] ;
$t_cnt = 1;
$t_filename = $title . "_" . $t_cnt;

#print "in_file " . $in_filename . "\n";
#print "title " . $title . "\n";
#print "t_titl " . $t_filename . "\n";
#print "Id " . $id . "\n";
#print "lane " . $lane . "\n";
#print "strand " . $strand . "\n";
#$b=<STDIN>;

$blseq_filename = $tmp_dirname  . $t_filename . ".fasta";
$reject_N_filename = $out_dirname . $title. "_N_reject.xls";
$reject_A_filename = $out_dirname . $title. "_A_reject.xls";
$reject_C_filename = $out_dirname . $title. "_C_reject.xls";
$reject_G_filename = $out_dirname . $title. "_G_reject.xls";
$reject_T_filename = $out_dirname . $title. "_T_reject.xls";
$display_filename = $out_dirname . $title. "_display.txt";

if (-e $display_filename) {`rm $display_filename`}
if (-e $blseq_filename) {`rm $blseq_filename`};
if (-e $reject_N_filename) {`rm $reject_N_filename`}
if (-e $reject_A_filename) {`rm $reject_A_filename`}
if (-e $reject_C_filename) {`rm $reject_C_filename`}
if (-e $reject_G_filename) {`rm $reject_G_filename`}
if (-e $reject_T_filename) {`rm $reject_T_filename`}

open(DISPLAY,">>$display_filename") || die "cannot open " . $display_filename;
open(REJECT_N,">$reject_N_filename") || die "cannot open " . $reject_N_filename;
open(REJECT_A,">$reject_A_filename") || die "cannot open " . $reject_A_filename;
open(REJECT_C,">$reject_C_filename") || die "cannot open " . $reject_C_filename;
open(REJECT_G,">$reject_G_filename") || die "cannot open " . $reject_G_filename;
open(REJECT_T,">$reject_T_filename") || die "cannot open " . $reject_T_filename;
open (BLSEQ,">$blseq_filename") or die "Cannot open $! " . $blseq_filename;

$start_time = time();
$st_time = $start_time;
#    print "Start Scan " . "\n";
#    print "filename " . $in_filename . "\n";
#    print $in_filename . "\n";
$fh = new IO::Uncompress::Gunzip $in_filename or die "IO::Uncompress::Gunzip failed: GunzipError\n";
$fnd = 1;
#    $b=<STDIN>;
while($fnd) {
    $line1_1 = $fh->getline();
    $line1_2 = $fh->getline();
    $line1_3 = $fh->getline();
    $line1_4 = $fh->getline();   

    $line1_1 =~ s/\r|\n//g;
    $line1_2 =~ s/\r|\n//g;
    $line1_3 =~ s/\r|\n//g;
    $line1_4 =~ s/\r|\n//g;
    
    if (eof($fh)) {
	$status = $fh->nextStream();
	if (!$status) {
	    $fnd = 0;
	}
    }
    $total_sample_cnt ++;
    $sample_cnt ++;
    if ($sample_cnt % 1000000 == 0) {
	$t_time = time();
	print DISPLAY "time " . ($t_time - $st_time) . "\n";
	print DISPLAY "Sample Cnt " . $sample_cnt . "\n";
	print DISPLAY "reject_cnt " . $reject_cnt . " blseq_cnt " . $blseq_cnt . "\n";
#	print "Sample Cnt " . $sample_cnt . "\n";
#	print "reject_cnt " . $reject_cnt . " blseq_cnt " . $blseq_cnt . "\n";
	$st_time = $t_time;
#	$b=<STDIN>;
    }
    
    $n_cnt = ($line1_2 =~ tr/N//)/length($line1_2);
    if ($n_cnt > $N_percent_cutoff ) {
	print REJECT_N $line1_1 . "\n";
	print REJECT_N $line1_2 . "\n";
	print REJECT_N $line1_3 . "\n";
	print REJECT_N $line1_4 . "\n";
	$reject_cnt ++;
	$total_reject_cnt ++;
	next;
    }
    $n_cnt = ($line1_2 =~ tr/A//)/length($line1_2);
    if ($n_cnt > $nuc_percent_cutoff ) {
	print REJECT_A $line1_1 . "\n";
	print REJECT_A $line1_2 . "\n";
	print REJECT_A $line1_3 . "\n";
	print REJECT_A $line1_4 . "\n";
	$reject_cnt ++;
	$total_reject_cnt ++;
	next;
    }
    $n_cnt = ($line1_2 =~ tr/C//)/length($line1_2);
    if ($n_cnt > $nuc_percent_cutoff ) {
	print REJECT_C $line1_1 . "\n";
	print REJECT_C $line1_2 . "\n";
	print REJECT_C $line1_3 . "\n";
	print REJECT_C $line1_4 . "\n";
	$reject_cnt ++;
	$total_reject_cnt ++;
	next;
    }
    $n_cnt = ($line1_2 =~ tr/G//)/length($line1_2);
    if ($n_cnt > $nuc_percent_cutoff ) {
	print REJECT_G $line1_1 . "\n";
	print REJECT_G $line1_2 . "\n";
	print REJECT_G $line1_3 . "\n";
	print REJECT_G $line1_4 . "\n";
	$reject_cnt ++;
	$total_reject_cnt ++;
	next;
    }
    $n_cnt = ($line1_2 =~ tr/T//)/length($line1_2);
    if ($n_cnt > $nuc_percent_cutoff ) {
	print REJECT_T $line1_1 . "\n";
	print REJECT_T $line1_2 . "\n";
	print REJECT_T $line1_3 . "\n";
	print REJECT_T $line1_4 . "\n";
	$reject_cnt ++;
	$total_reject_cnt ++;
	next;
    }
    print BLSEQ ">" . $line1_1 . "\n" . $line1_2 . "\n";
    $blseq_cnt ++;
    $total_blseq_cnt ++;
    
    if ($sample_cnt % 1000000 == 0) {
	close(BLSEQ);
	$t_cnt ++;
	$t_filename = $title . "_" . $t_cnt;
	$blseq_filename = $tmp_dirname  . $t_filename . ".fasta";
	if (-e $blseq_filename) {`rm $blseq_filename`};
	open (BLSEQ,">$blseq_filename") or die "Cannot open $! " . $blseq_filename;
	print DISPLAY "new filename " . $blseq_filename . "\n";
    }
}## end while fnd
#    close(INFILE);
close(REJECT_N);
close(REJECT_A);
close(REJECT_C);
close(REJECT_G);
close(REJECT_T);
close(BLSEQ);

$t_time = time();
print DISPLAY "\ntotal time " . ($t_time - $start_time) . "\n";
print DISPLAY "File Name " . $in_filename . " Sample Cnt " . $sample_cnt . "\n";
print DISPLAY "BLSEQ Cnt " . $blseq_cnt . " Reject Cnt " . $reject_cnt . "\n";
close(DISPLAY);
#}##file count
open(DISPLAY,">>$log_filename") || die "cannot open " . $log_filename;
$t_time = time();
print DISPLAY "\nFinal total time " . ($t_time - $start_time) . "\n";
print DISPLAY "Sample Cnt " . $total_sample_cnt . "\n";
print DISPLAY "BLSEQ Cnt " . $total_blseq_cnt . " Reject Cnt " . $total_reject_cnt . "\n";
close(DISPLAY);

exit 0;
