#!/bin/bash

run_flag=$1

if [ $# -ne 1 ]; then
    run_flag=0
fi

dir_name=""
script_name=$dir_name"script/complete_blast_cluster.pl"
pbs_dir=$dir_name"pbs_files/"
error_dir=$dir_name"error/"
in_dir=$dir_name"blast_out/"
cd $in_dir
fastq_files="$(ls *_R1_*_blast.txt)"
#    fastq_files="$(ls LH_25_R1_*_blast.txt)"

for ff in $fastq_files;do
    echo $ff
    sname=${ff%*_blast.txt}
    out2_filename=$sname
    pbs_filename=$pbs_dir$sname"_complete_blast.pbs"

    error_filename=$error_dir$sname"_error.log"
    output_filename=$error_dir$sname"_out.log"
    echo "#!/bin/bash" > $pbs_filename 
    echo "#SBATCH" >> $pbs_filename
    echo "#SBATCH --account=dginsburglab" >> $pbs_filename
    echo "#SBATCH --partition=dgcomp" >> $pbs_filename
    echo "#SBATCH --mail-user=siemieni@umich.edu" >> $pbs_filename
    echo "#SBATCH --job-name=$sname " >> $pbs_filename
    echo "#SBATCH --output=$output_filename" >> $pbs_filename
    echo "#SBATCH --error=$error_filename" >> $pbs_filename 
    echo "#SBATCH --nodes=1" >> $pbs_filename
    echo "#SBATCH --cpus-per-task=1 " >>$pbs_filename
    echo "#SBATCH --mem=2G " >>$pbs_filename
    echo "#SBATCH --time=120:00:00" >> $pbs_filename

    echo $script_name $out2_filename >> $pbs_filename
    if [ $run_flag -eq 1 ]; then
	sbatch $pbs_filename
	#	    echo "qsub"
    fi
done

fastq_files="$(ls *_R2_*_blast.txt)"
#    fastq_files="$(ls LH_25_R2_*_blast.txt)"
for ff in $fastq_files;do
    echo $ff
    sname=${ff%*_blast.txt}
    out2_filename=$sname
    pbs_filename=$pbs_dir$sname"_complete_blast.pbs"

    error_filename=$error_dir$sname"_error.log"
    output_filename=$error_dir$sname"_out.log"
    echo "#!/bin/bash" > $pbs_filename 
    echo "#SBATCH" >> $pbs_filename
    echo "#SBATCH --account=dginsburglab" >> $pbs_filename
    echo "#SBATCH --partition=dgcomp" >> $pbs_filename
    echo "#SBATCH --mail-user=siemieni@umich.edu" >> $pbs_filename
    echo "#SBATCH --job-name=$sname " >> $pbs_filename
    echo "#SBATCH --output=$output_filename" >> $pbs_filename
    echo "#SBATCH --error=$error_filename" >> $pbs_filename 
    echo "#SBATCH --nodes=1" >> $pbs_filename
    echo "#SBATCH --cpus-per-task=1 " >>$pbs_filename
    echo "#SBATCH --mem=2G " >>$pbs_filename
    echo "#SBATCH --time=120:00:00" >> $pbs_filename

    echo $script_name $out2_filename >> $pbs_filename
    if [ $run_flag -eq 1 ]; then
	sbatch $pbs_filename 
	#	    echo "qsub"
    fi
done
echo done
exit
