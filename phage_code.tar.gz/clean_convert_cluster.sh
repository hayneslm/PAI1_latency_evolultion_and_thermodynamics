#!/bin/bash

run_flag=$1

if [ $# -ne 1 ]; then
    run_flag=0
fi

main_dirname=""
in_dir=$main_dirname"fastq/"
script_dir=$main_dirname"script/"
pbs_dir=$main_dirname"pbs_files/"
output_dir=$main_dirname"error/"

cd $in_dir
files="$(ls *.fastq.gz)"
for ff in $files;do
#    sname=${ff%*.fastq.gz}
    echo "ff "$ff
    id=$(echo $ff | cut -d_ -f1)
    lane=$(echo $ff | cut -d_ -f2)
    lane1=${lane:0:6}
    strand=$(echo $ff | cut -d_ -f4)
    #sname=${ff%*.fasta}
#    strand=${strand1%*.fastq.gz}
    in_filename=$in_dir$ff
    sname=$id"_"$lane1"_"$strand

#    echo "infilename "$in_filename
#    echo "id "$id
#    echo "lane "$lane
#    echo "lane1 "$lane1
#    echo "strand "$strand
#    echo "strand1 "$strand1
#    echo "sname "$sname
#    read -p "prompt "

    pbs_filename=$pbs_dir$sname"_clean_convert.pbs"

    error_filename=$error_dir$sname"_error.log"
    output_filename=$error_dir$sname"_out.log"
    echo "#!/bin/bash" > $pbs_filename 
    echo "#SBATCH" >> $pbs_filename
    echo "#SBATCH --account=dginsburglab" >> $pbs_filename
    echo "#SBATCH --partition=dgcomp" >> $pbs_filename
    echo "#SBATCH --mail-user=siemieni@umich.edu" >> $pbs_filename
    echo "#SBATCH --job-name=$sname " >> $pbs_filename
    echo "#SBATCH --output=$output_filename" >> $pbs_filename
    echo "#SBATCH --error=$error_filename" >> $pbs_filename 
    echo "#SBATCH --nodes=1" >> $pbs_filename
    echo "#SBATCH --cpus-per-task=1 " >>$pbs_filename
    echo "#SBATCH --mem=5G " >>$pbs_filename
    echo "#SBATCH --time=120:00:00" >> $pbs_filename

    echo $script_dir"clean_convert_to_fasta.pl "$ff  >> $pbs_filename
    if [ $run_flag -eq 1 ]; then
	sbatch $pbs_filename 
    fi
done
echo done
exit

