#!/usr/bin/perl -w

$title = $ARGV[0];

$main_dirname = "";
require $main_dirname . "script/process_proc.pl";
$display = 0;
$in_dirname = $main_dirname . "clean_result/";
$out_dirname = $main_dirname . "amplicon_result/";

@tmp = split("_",$title);
#for ($tt=0;$tt<=$#tmp;$tt++) {
#    print "tt " . $tt . " - " .$tmp[$tt] . "\n";
#}
$title1 = $title;
$amp = int($tmp[3]); 
#$title1 = $tmp[0] . "_" .$tmp[1] ."_" . $tmp[2];
#$title1 = $tmp[0] . "_" .$tmp[1] ."_" . $tmp[2] . "_" . $tmp[3];
#print "title " . $title . "\n";
#print "title1 " . $title1 . "\n";
#print "amp " . $amp . "\n";
#$b=<STDIN>;

$ref_dirname = "";
undef(@amp_seq);
undef(@amp_pep);
undef(@trim_pep);
$infilename = $ref_dirname . "pai1_amp1-12.fasta";
open(INFILE,"$infilename") || die "cannot open file " . $infilename;
$fnd = 1;
while ($fnd) {
    $line1 = readline(*INFILE);
    $line2 = readline(*INFILE);
#    print "line1 " . $line1;
#    print "line2 " . $line2;
#    $b=<STDIN>;
    if (eof(INFILE)) {$fnd = 0};
    $line1 =~ s/\r|\n//g;
    $line2 =~ s/\r|\n//g;
    $line1 =~ s/>//;
    push(@amp_seq,uc($line2));
}
close(INFILE);
$infilename = $ref_dirname . "pai1_amp1-12_pep.fasta";
open(INFILE,"$infilename") || die "cannot open file " . $infilename;
$fnd = 1;
while ($fnd) {
    $line1 = readline(*INFILE);
    $line2 = readline(*INFILE);
    if (eof(INFILE)) {$fnd = 0};
    $line1 =~ s/\r|\n//g;
    $line2 =~ s/\r|\n//g;
    $line1 =~ s/>//;
    push(@amp_pep, uc($line2));
}
close(INFILE);

$infilename = $ref_dirname . "pai1_amp1-12_pep_trimed.fasta";
open(INFILE,"$infilename") || die "cannot open file " . $infilename;
$fnd = 1;
while ($fnd) {
    $line1 = readline(*INFILE);
    $line2 = readline(*INFILE);
    if (eof(INFILE)) {$fnd = 0};
    $line1 =~ s/\r|\n//g;
    $line2 =~ s/\r|\n//g;
    $line1 =~ s/>//;
    push(@trim_pep, uc($line2));
}
close(INFILE);

undef(@ref_pep_list);
undef(@trim_ref_pep_list);
undef(%pep_conversion);
undef(@ref_seq);
undef(@aa_list);
undef(%pep_found);
undef(%trim_pep_X_found);
undef(%trim_pep_B_found);
undef(%nuc_found);
undef(%complete_nuc);
undef(%no_primer_nuc);
undef(%no_primer_pep);
undef(%codon_usage);

$pos = 1;
$in_filename = $ref_dirname . "amino_acid.csv";
open(INFILE,"$in_filename") || die "cannot open " . $in_filename;
while(<INFILE>) {
    $_ =~ s/\r|\n//g;
    @line = split(",",$_);
#    for ($tt=0;$tt<=$#line;$tt++) {                                                                                                                                         
#   print "tt " . $tt . " - " .$line[$tt] . "\n";                                                                                                                            
#    }                                                                                                                                                                       
#    $b=<STDIN>;                                                                                                                                                             
    push(@aa_list,[$line[0],$line[1],$line[2]]);
    $pep_conversion{$line[2]} = $pos;
    $pos++;
}
close(INFILE);

for ($tt=0;$tt<length($amp_seq[$amp - 1]);$tt++) {
    push(@ref_seq,[substr($amp_seq[$amp -1 ],$tt,1),0,0,0,0,0]);
}
$refer_seq = $amp_seq[$amp-1];
$refer_pep = $amp_pep[$amp-1];
$trim_refer_pep = $trim_pep[$amp -1];

$ref_pep_list[0][0] = "Code/AA";
for ($tt=1;$tt<=$#aa_list;$tt++) {
    $ref_pep_list[0][$tt] = $aa_list[$tt -1][2];
}
for ($tt=0;$tt<length($refer_pep);$tt++) {
    $ref_pep_list[$tt+1][0] = substr($refer_pep,$tt,1);
    for ($tt1=1;$tt1<=$#aa_list;$tt1++) {
        $ref_pep_list[$tt+1][$tt1] = 0;
    }
}

$trim_ref_pep_list[0][0] = "Code/AA";
for ($tt=1;$tt<=$#aa_list;$tt++) {
    $trim_ref_pep_list[0][$tt] = $aa_list[$tt -1][2];
}
for ($tt=0;$tt<length($trim_refer_pep);$tt++) {
    $trim_ref_pep_list[$tt+1][0] = substr($trim_refer_pep,$tt,1);
    for ($tt1=1;$tt1<=$#aa_list;$tt1++) {
        $trim_ref_pep_list[$tt+1][$tt1] = 0;
    }
}

$st_time = time();
if ($amp == 1) {
    $amp_start = 1;
    $amp_end = 150; 
    $trim_start = 14;
    $trim_length = 28;
    $primer_f_len = 30;
    $primer_r_len = 21;
} elsif ($amp == 2) {
    $amp_start = 100;
    $amp_end = 248; 
    $trim_start = 9;
    $trim_length = 28;
    $primer_f_len = 21;
    $primer_r_len = 26;
} elsif ($amp == 3) {
    $amp_start = 175;
    $amp_end = 324; 
    $trim_start = 12;
    $trim_length = 27;
    $primer_f_len = 21;
    $primer_r_len = 24;
} elsif ($amp == 4) {
    $amp_start = 262;
    $amp_end = 411;
    $trim_start = 10;
    $trim_length = 31;
    $primer_f_len = 21;
    $primer_r_len = 19;
} elsif ($amp == 5) {
    $amp_start = 352;
    $amp_end = 501; 
    $trim_start = 11;
    $trim_length = 30;
    $primer_f_len = 21;
    $primer_r_len = 24;
} elsif ($amp == 6) {
    $amp_start = 441;
    $amp_end = 590; 
    $trim_start = 11;
    $trim_length = 31;
    $primer_f_len = 27;
    $primer_r_len = 19;
} elsif ($amp == 7) {
    $amp_start = 541;
    $amp_end = 690;
    $trim_start = 9;
    $trim_length = 33;
    $primer_f_len = 21;
    $primer_r_len = 22;
} elsif ($amp == 8) {
    $amp_start = 640;
    $amp_end = 789;
    $trim_start = 9;
    $trim_length = 34;
    $primer_f_len = 21;
    $primer_r_len = 19;
} elsif ($amp == 9) {
    $amp_start = 742;
    $amp_end = 891;
    $trim_start = 9;
    $trim_length = 32;
    $primer_f_len = 18;
    $primer_r_len = 18;
} elsif ($amp == 10) {
    $amp_start = 843;
    $amp_end = 992;
    $trim_start = 7;
    $trim_length = 35;
    $primer_f_len = 15;
    $primer_r_len = 20;
} elsif ($amp == 11) {
    $amp_start = 940;
    $amp_end = 1089;
    $trim_start = 10;
    $trim_length = 34;
    $primer_f_len = 21;
    $primer_r_len = 15;
} elsif ($amp == 12) {
    $amp_start = 1051;
    $amp_end = 1200;
    $trim_start = 7;
    $trim_length = 36;
    $primer_f_len = 18;
    $primer_r_len = 21; 
}
$master_filename = $out_dirname . $title1 . "_screen_amplicon_master_count.xls";
$seq_error_filename = $out_dirname . $title1 ."_seq_error.txt";
$mut_filename = $out_dirname . $title1 ."_valid_mutant.txt";
$matrix_filename = $out_dirname . $title1 ."_seq_matrix.xls";
$pep_count_filename = $out_dirname . $title1. "_peptide_count_list.xls";
$trim_pep_count_filename = $out_dirname . $title1. "_peptide_count_list_trim_X.xls";
$trim_pep_count_B_filename = $out_dirname . $title1. "_peptide_count_list_trim_B.xls";
$nuc_count_filename = $out_dirname . $title1. "_nuc_count_list.xls";
$display_filename = $out_dirname . $title1 . "_display_info.txt";
$pep_list_count_filename = $out_dirname . $title1 . "_peptide_breakdown_matrix.xls";
$trim_pep_list_count_filename = $out_dirname . $title1 . "_peptide_breakdown_matrix_trim.xls";
$codon_usage_filename = $out_dirname . $title1 . "_codon_usage.xls";
$no_primer_nuc_count_filename = $out_dirname . $title1 . "_no_primer_nuc_count_list.xls";
$no_primer_pep_count_filename = $out_dirname . $title1 . "_no_primer_pep_count_list.xls";
$complete_nuc_count_filename = $out_dirname . $title1. "_complete_nuc_count_list.xls";

open(ERR,">$seq_error_filename") || die "cannot open " . $seq_error_filename;
print ERR join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","flag","#Mis_Match","R1_start","R1_end","Consensus line","Second line") . "\n";
open(MUT,">$mut_filename") || die "cannot open " . $mut_filename;
print MUT join("\t","Seq Id","R1 Seq","R2 Seq","Combine start","Combine end","%R1","%R2","R1 start","R1 end","R2 strt","R2 end","R1 Gap","R2 gap","flag","#Ref Mis_Match","Consensus seq","Ref Line","#Pep Mismatch","Pep Seq","R1 start","R2 start","REF_end","Pre Seq","Post Seq") . "\n";
open(DISPLAY,">$display_filename") || die "cannot open " . $display_filename;
$seq_cnt = 0;
$err_cnt = 0;
$per_cnt = 0;
$mut_cnt = 0;	
$scan_cnt = 0;
$peptide_cnt = 0;

$infile = $in_dirname . $title . "_valid_result.txt";
open(INFILE,$infile) || die "cannot open file " . $infile;
readline(*INFILE);
while (<INFILE>) {
    $_ =~ s/\r|\n//g;
    @line = split("\t",$_);
#	    for ($tt=0;$tt<=$#line;$tt++) {
#		print "tt " . $tt . " - " .$line[$tt] . "\n";
#	    }
#	    $b=<STDIN>;
    $seq_cnt ++;
    if ($seq_cnt % 100000 == 0 ) {
#	print "seq_cnt " . $seq_cnt . " err_cnt " . $err_cnt . " per_cnt " . $per_cnt . " mut_cnt " . $mut_cnt . " amp " . $amp . "\n";
	$t_time = time();
	$tot_time = $t_time - $st_time;
#	print "time " . $tot_time . "\n";
	print DISPLAY  "seq_cnt " . $seq_cnt . " err_cnt " . $err_cnt . " per_cnt " . $per_cnt . " mut_cnt " . $mut_cnt . " amp " . $amp . " time " . $tot_time . "\n";
	$st_time = $t_time;
#	$b=<STDIN>;
   }
    if ($line[9] >= $line[7]) {
	if ($line[9] == $line[7]) {
	    $r1_start = 0;
	    $r2_start = 0;
	} else {
	    $r1_start = $line[9] - $line[7];
	    $r2_start = 0;
	}
	
	if ($line[10] < $line[8]) {
	    $r1_end = length($line[2]) - $r1_start;
	} else {
	    $r1_end = length($line[1]) - $r1_start;
	}
	$con_line = "";
	$tline1 = "";
	$mis = 0;
	for ($tt=$r1_start;$tt<$r1_end;$tt++) {
	    if (!substr($line[2],($r2_start),1) || !substr($line[1],$tt,1)) {
		##ran out of sequences to review
		print "tt " . $tt . " r1_start " . $r1_start . " r1_end " . $r1_end ."\nline1 " . $line[1] . "\nline2 " . $line[2] . "\nline[10] " . $line[10] . " line[8] " . $line[8] . "\n";
		$b=<STDIN>;
		last;
	    }
	    $con_line .= substr($line[1],$tt,1);
	    $tline1 .= substr($line[2],($r2_start),1);
	    if (substr($line[1],$tt,1) ne substr($line[2],$r2_start,1)) {
		$mis ++;
	    }
	    $r2_start ++;
	}##for loop
	if ($mis) {
	    ## mismatch between r1 and r2 sequences
	    print ERR $_ . "\t" . join("\t",$mis,$r1_start,$r1_end,$con_line,$tline1,"seq_err") . "\n";
	    $err_cnt ++;
	    next;
	}
	if (length($con_line) + $r1_start > length($refer_seq)) {
	    $con_line = substr($con_line,0,(length($refer_seq) - $ref_start));
	}
	
    } else {##line9>line7
	print "aa\n";
	$b=<STDIN>;
    }
    
########################################################
## both seq the same between R1 and R2 region, now compare to ref
    $ref_start = $line[9] - $amp_start;
    $tmp_skip = 0;
    if ($ref_start <= 0) {
	#               print "con_Line " . $con_line . "\n";
	if ($amp == 6 || $amp == 10) {
	    $tmp_skip = abs($line[9] - $amp_start) +1;
	} else {
	    $tmp_skip = abs($line[9] - $amp_start);
	}
	$con_line = substr($con_line,$tmp_skip);
	$ref_start = 0;
    } else {
	if ($amp == 6 || $amp == 10) {
	    if ($ref_start != 0) {
		$ref_start = $line[9] - $amp_start - 1 ;
	    }
	} else {
	    $ref_start = $line[9] - $amp_start;
	}
    }
    $ref_end = length($con_line) + $ref_start;
    if ($ref_end > length($refer_seq) ) {
	$ref_end = length($refer_seq);
    }
    
    $ref_line = "";
    $con_pos = 0;
    $ref_mis = 0;
    $scan_cnt ++;
    for ($l_pos=$ref_start;$l_pos<$ref_end;$l_pos++) {
	$ref_line .= substr($refer_seq,$l_pos,1);
	$nuc = substr($con_line,$con_pos,1);
	if ($nuc =~ /A/) {
	    $ref_seq[$l_pos][1] ++;
	} elsif ($nuc =~ /C/) {
	    $ref_seq[$l_pos][2] ++;
	} elsif ($nuc =~ /G/) {
	    $ref_seq[$l_pos][3] ++;
	} elsif ($nuc =~ /T/) {
	    $ref_seq[$l_pos][4] ++;
	} else {
	    $ref_seq[$l_pos][5] ++;
	}
	if (substr($refer_seq,$l_pos,1) ne substr($con_line,$con_pos,1)) {
            $ref_mis ++;
	}			    
	$con_pos ++;
    }## while l_pos
    
    if (exists($nuc_found{$con_line})) {
	$nuc_found{$con_line} ++;
    } else {
	$nuc_found{$con_line} = 1;
    }
    if ($display) {
	print "first refer_seq " . $refer_seq . "\n";
	print "con_seq " . $con_line . "\n";
	print "ref_line ".$ref_line."\n";
	print "ref_mis " . $ref_mis . "\n";
	print "ref_start " . $ref_start . "\n";
	print "amp " . $amp . "\n";
	print "amp_start " . $amp_start . "\n";
	    
    }
#    $b=<STDIN>;
######################## start protien section		
############## a mismatch between ref seq and con seq, this is what we are looking for.
    $m_seq = "";
    $tmp_pep = "";
    $pre = "";
    $post = "";

    $pre = substr($refer_seq,0,$ref_start);
    if ($ref_start + length($con_line) <= length($refer_seq)) {
	$post = substr($refer_seq,($ref_start + length($con_line)));
    } else {
	$post = "";
    }
    
    $m_seq = $pre . $con_line . $post;
    if (length($m_seq) > length($refer_seq)) {
	$m_seq = substr($m_seq,0,length($refer_seq));
    }
    $tmp_pep = translate_seq_to_protein($m_seq);
    $peptide_cnt ++;

    for ($ww=1;$ww<=length($tmp_pep);$ww++) {
        $ref_pep_list[$ww][$pep_conversion{substr($tmp_pep,($ww -1),1)}] ++;
    }

    undef($trim_pep);
    $pos = 1 ;
    for ($tt=$trim_start;$tt<=($trim_length + $trim_start -1);$tt++) {
	$nuc = substr($tmp_pep,$tt,1);
	$trim_ref_pep_list[$pos][$pep_conversion{$nuc}] ++;
	$trim_pep .= $nuc;
	$pos ++;
    } 
    $trim_peptide_cnt ++;

    if (exists($pep_found{$tmp_pep})) {
	$pep_found{$tmp_pep} ++;
    } else {
	$pep_found{$tmp_pep} = 1;
    }

    if (exists($trim_pep_B_found{$trim_pep})) {
	$trim_pep_B_found{$trim_pep} ++;
    } else {
	$trim_pep_B_found{$trim_pep} = 1;
    }

    $trim_pep =~ s/B/X/g;
    if (exists($trim_pep_X_found{$trim_pep})) {
	$trim_pep_X_found{$trim_pep} ++;
    } else {
	$trim_pep_X_found{$trim_pep} = 1;
    }


    $pep_mis = 0;
    for ($tt1=0;$tt1<(length($refer_pep)-1) ;$tt1++) {
	if (substr($refer_pep,$tt1,1) ne substr($tmp_pep,$tt1,1)) {
	    $pep_mis ++;
	}
    }
##remove primer seq here 
    $stop_primer_pos = length($m_seq) - $primer_r_len - $primer_f_len;
    $valid_no_primer_seq = substr($m_seq,$primer_f_len,$stop_primer_pos);
    $valid_no_primer_pep = translate_seq_to_protein($valid_no_primer_seq);

    if (exists($no_primer_nuc{$valid_no_primer_seq})) {
        $no_primer_nuc{$valid_no_primer_seq} ++;
    } else {
        $no_primer_nuc{$valid_no_primer_seq} = 1;
    }
    if (exists($no_primer_pep{$valid_no_primer_pep})) {
	$no_primer_pep{$valid_no_primer_pep} ++;
    } else {
        $no_primer_pep{$valid_no_primer_pep} = 1;
    }

##total nuc ceq                                                                                                                                                               
    if (exists($complete_nuc{$m_seq})) {
        $complete_nuc{$m_seq} ++;
    } else {
        $complete_nuc{$m_seq} = 1;
    }

##codon usage                                                                                                                                                                 
    $end_codon = int(length($m_seq)/3) * 3;
    for ($tt2=0;$tt2<$end_codon;$tt2+=3) {
        $codon = uc(substr($m_seq,$tt2,3));
        if (!exists($codon_usage{$codon})) {
            $codon_usage{$codon} = 1;
        } else {
            $codon_usage{$codon} ++;
        }
    }
    if ($display) {
        for ($tt1=0;$tt1<=$#line;$tt1++) {
            print "tt " . $tt1 . " - " .$line[$tt1] . "\n";
        }
        print "length line1 " . length($line[1]) . "\n";
        print "length line2 " . length($line[2]) . "\n";
        print "r1_start " . $r1_start . "\n";
        print "r2_start " . $r2_start . "\n";
        print "r1_end " . $r1_end . "\n";
        print "ref_start " . $ref_start . " ref_end " . $ref_end . "\n";
        print "pre " . $pre . " post " . $post . "\n";
        print "conline " .$con_line . "\n";
        print "mseq " . $m_seq . "\n";
        print "refer_seq " . $refer_seq . "\n";
        print "ref_pep " . $refer_pep . " tmp_pep " . $tmp_pep . "\n";
        print "valid_seq " . $valid_no_primer_seq ."\n";
        print "stop_pos " . $stop_primer_pos . "\n";
        $b=<STDIN>;
    }

    print MUT $_ ."\t". join("\t",$ref_mis,$con_line,$ref_line,$pep_mis,$tmp_pep,$r1_start,$r2_start,$ref_start,$ref_end,$pre,$post,"valid") . "\n";
    if ($ref_mis) {
	$mut_cnt ++;
    } else { ##ref_mis = 0
	$per_cnt ++;
    }
}##while infile
close(MUT);
close(ERR);
close(INFILE);

#nuc matrix
$outline = "Pos\tNuc\tA_cnt\tC_cnt\tG_cnt\tT_cnt\tN_cnt\n";
for ($tt=0;$tt<=$#ref_seq;$tt++) {
    $n_pos = $amp_start + $tt; 
    $outline .= join("\t",$n_pos,$ref_seq[$tt][0],$ref_seq[$tt][1],$ref_seq[$tt][2],$ref_seq[$tt][3],$ref_seq[$tt][4],$ref_seq[$tt][5]) . "\n";
}
open(MAT,">$matrix_filename") || die "cannot open " . $matrix_filename;
print MAT $outline;
close(MAT);

## peptide found
undef(@tmp_cnt);
foreach $key (keys %pep_found) {
    push(@tmp_cnt,[$key,$pep_found{$key}]);
}
undef(@sort_cnt);
@sort_cnt = sort { int($b->[1]) <=> int($a->[1]) } @tmp_cnt;
$pep_sort_cnt = $#sort_cnt + 1;
open(PEP,">$pep_count_filename") || die "cannot open " . $pep_count_filename;
print PEP "Count\tPeptide\n";
for ($tt=0;$tt<=$#sort_cnt;$tt++) {
    print PEP join("\t",$sort_cnt[$tt][1],$sort_cnt[$tt][0]) . "\n";
}
close(PEP);

## trim peptide_B found
undef(@tmp_cnt);
foreach $key (keys %trim_pep_B_found) {
    push(@tmp_cnt,[$key,$trim_pep_B_found{$key}]);
}
undef(@sort_cnt);
@sort_cnt = sort { int($b->[1]) <=> int($a->[1]) } @tmp_cnt;
$trim_pep_sort_cnt = $#sort_cnt + 1;
open(PEP,">$trim_pep_count_B_filename") || die "cannot open " . $trim_pep_count_B_filename;
print PEP "Count\tPeptide\n";
for ($tt=0;$tt<=$#sort_cnt;$tt++) {
    print PEP join("\t",$sort_cnt[$tt][1],$sort_cnt[$tt][0]) . "\n";
}
close(PEP);

## trim peptide_X found
undef(@tmp_cnt);
foreach $key (keys %trim_pep_X_found) {
    push(@tmp_cnt,[$key,$trim_pep_X_found{$key}]);
}
undef(@sort_cnt);
@sort_cnt = sort { int($b->[1]) <=> int($a->[1]) } @tmp_cnt;
$trim_pep_sort_cnt = $#sort_cnt + 1;
open(PEP,">$trim_pep_count_filename") || die "cannot open " . $trim_pep_count_filename;
print PEP "Count\tPeptide\n";
for ($tt=0;$tt<=$#sort_cnt;$tt++) {
    print PEP join("\t",$sort_cnt[$tt][1],$sort_cnt[$tt][0]) . "\n";
}
close(PEP);

## nuc_found
undef(@tmp_cnt);
foreach $key (keys %nuc_found) {
    push(@tmp_cnt,[$key,$nuc_found{$key}]);
}
undef(@sort_cnt);
@sort_cnt = sort { int($b->[1]) <=> int($a->[1]) } @tmp_cnt;
$nuc_sort_cnt = $#sort_cnt + 1;
open(PEP,">$nuc_count_filename") || die "cannot open " . $nuc_count_filename;
print PEP "Count\tNuc String\n";
for ($tt=0;$tt<=$#sort_cnt;$tt++) {
    print PEP join("\t",$sort_cnt[$tt][1],$sort_cnt[$tt][0]) . "\n";
}
close(PEP);

## no_primer_nuc                                                                                                                                                             
undef(@tmp_cnt);
foreach $key (keys %no_primer_nuc) {
    push(@tmp_cnt,[$key,$no_primer_nuc{$key}]);
}
undef(@sort_cnt);
@sort_cnt = sort { int($b->[1]) <=> int($a->[1]) } @tmp_cnt;
$nuc_sort_cnt = $#sort_cnt + 1;
open(PEP,">$no_primer_nuc_count_filename") || die "cannot open " . $no_primer_nuc_count_filename;
print PEP "Count\tNuc String\n";
for ($tt=0;$tt<=$#sort_cnt;$tt++) {
    print PEP join("\t",$sort_cnt[$tt][1],$sort_cnt[$tt][0],length($sort_cnt[$tt][0])) . "\n";
}
close(PEP);

##no_prinmer_pep                                                                                                                        
undef(@tmp_cnt);
foreach $key (keys %no_primer_pep) {
    push(@tmp_cnt,[$key,$no_primer_pep{$key}]);
}
undef(@sort_cnt);
@sort_cnt = sort { int($b->[1]) <=> int($a->[1]) } @tmp_cnt;
$nuc_sort_cnt = $#sort_cnt + 1;
open(PEP,">$no_primer_pep_count_filename") || die "cannot open " . $no_primer_pep_count_filename;
print PEP "Count\tNuc String\n";
for ($tt=0;$tt<=$#sort_cnt;$tt++) {
    print PEP join("\t",$sort_cnt[$tt][1],$sort_cnt[$tt][0],length($sort_cnt[$tt][0])) . "\n";
}
close(PEP);

##complete_nuc                                                                                                                                                                
undef(@tmp_cnt);
foreach $key (keys %complete_nuc) {
    push(@tmp_cnt,[$key,$complete_nuc{$key}]);
}
undef(@sort_cnt);
@sort_cnt = sort { int($b->[1]) <=> int($a->[1]) } @tmp_cnt;
$complete_nuc_sort_cnt = $#sort_cnt + 1;
open(PEP,">$complete_nuc_count_filename") || die "cannot open " . $complete_nuc_count_filename;
print PEP "Count\tNuc String\n";
for ($tt=0;$tt<=$#sort_cnt;$tt++) {
    print PEP join("\t",$sort_cnt[$tt][1],$sort_cnt[$tt][0],length($sort_cnt[$tt][0])) . "\n";
}
close(PEP);

###codon usage                                                                                                                                                                 
undef(@tmp_cnt);
foreach $key (keys %codon_usage) {
    push(@tmp_cnt,[$key,$codon_usage{$key}]);
}
undef(@sort_cnt);
@sort_cnt = sort { int($b->[1]) <=> int($a->[1]) } @tmp_cnt;
$codon_sort_cnt = $#sort_cnt + 1;
open(PEP,">$codon_usage_filename") || die "cannot open " . $codon_usage_filename;
print PEP "Codon\tCount\n";
for ($tt=0;$tt<=$#sort_cnt;$tt++) {
    print PEP join("\t",$sort_cnt[$tt][0],$sort_cnt[$tt][1]) . "\n";
}
close(PEP);

##peptide matrix
$outline = "";
for ($tt=0;$tt<=$#ref_pep_list;$tt++) {
    for ($ww=0;$ww<=$#aa_list;$ww++) {
        $outline .= $ref_pep_list[$tt][$ww] . "\t";
    }
    chop($outline);
    $outline .= "\n";
}
open(PEP,">$pep_list_count_filename") || die "cannot open " . $pep_list_count_filename;
print PEP $outline;
close(PEP);

##trim_peptide matrix
$outline = "";
for ($tt=0;$tt<=$#trim_ref_pep_list;$tt++) {
    for ($ww=0;$ww<=$#aa_list;$ww++) {
        $outline .= $trim_ref_pep_list[$tt][$ww] . "\t";
    }
    chop($outline);
    $outline .= "\n";
}
open(PEP,">$trim_pep_list_count_filename") || die "cannot open " . $trim_pep_list_count_filename;
print PEP $outline;
close(PEP);

$ed_time = time();
$total_time = $ed_time - $st_time;
print DISPLAY "Title " . $title . " amp " . $amp . " seq_cnt " . $seq_cnt . " scan_cnt " . $scan_cnt ."\n" ;
print DISPLAY "err_cnt " . $err_cnt . " per_cnt " . $per_cnt . " mut_cnt " . $mut_cnt . " peptide_cnt " . $peptide_cnt . " trim_peptide_cnt " . $trim_peptide_cnt . "\n";
print DISPLAY "nuc_sort_cnt " . $nuc_sort_cnt . " pep_sort_cnt " . $pep_sort_cnt . " trim_pep_sort_cnt " . $trim_pep_sort_cnt . "\n";
print DISPLAY "complete_nuc_sort_cnt " . $complete_nuc_sort_cnt . " codon_sort_cnt " . $codon_sort_cnt ."\n";
print DISPLAY "total time " . $total_time . "\n";
close(DISPLAY);
open(M_LIST,">>$master_filename") || die "cannot open " . $master_filename;
print M_LIST join(",",$title,$amp,$seq_cnt,$scan_cnt,$err_cnt,$per_cnt,$mut_cnt,$peptide_cnt,$pep_sort_cnt,$nuc_sort_cnt,$total_time) ."\n";
close(M_LIST);	


exit 0;
