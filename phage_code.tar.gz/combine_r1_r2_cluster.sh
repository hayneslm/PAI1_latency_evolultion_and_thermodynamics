#!/bin/bash

run_flag=$1

if [ $# -ne 1 ]; then
    run_flag=0
fi

dir_name=""
pbs_dir=$dir_name"pbs_files/"
error_dir=$dir_name"error/"
in_dir=$dir_name"blast_result/combine/";

combine_code=$dir_name"script/combine_r1_r2.pl "
#combine_code=$dir_name"script/combine_r1_r2_single.pl "

cd $in_dir
files="$(ls *_R1_pai1_match.xls)"
for ff in $files;do
    echo $ff
    sname=${ff%*_R1_pai1_match.xls}
    pbs_filename=$pbs_dir$sname"_combine_R1_R2.pbs"

    error_filename=$error_dir$sname"_error.log"
    output_filename=$error_dir$sname"_out.log"
    echo "#!/bin/bash" > $pbs_filename 
    echo "#SBATCH" >> $pbs_filename
    echo "#SBATCH --account=dginsburglab" >> $pbs_filename
    echo "#SBATCH --partition=dgcomp" >> $pbs_filename
    echo "#SBATCH --mail-user=siemieni@umich.edu" >> $pbs_filename
    echo "#SBATCH --job-name=$sname " >> $pbs_filename
    echo "#SBATCH --output=$output_filename" >> $pbs_filename
    echo "#SBATCH --error=$error_filename" >> $pbs_filename 
    echo "#SBATCH --nodes=1" >> $pbs_filename
    echo "#SBATCH --cpus-per-task=1 " >>$pbs_filename
    echo "#SBATCH --mem=90G " >>$pbs_filename
    echo "#SBATCH --time=120:00:00" >> $pbs_filename

    echo $combine_code$sname >> $pbs_filename
    if [ $run_flag -eq 1 ]; then
	sbatch $pbs_filename 
    fi
done
echo done
exit
